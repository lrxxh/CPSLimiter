package lrxh;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class CPSLimiterPlugin extends JavaPlugin implements Listener {

    private Map<Player, Long> clickTimestamps = new HashMap<>();
    private int cpsLimit = 28; // Set your desired CPS limit here

    @Override
    public void onEnable() {
        getConfig().options().copyDefaults(true);
        saveConfig();
        Constants.loadConfig((Plugin)this);
        getLogger().info("Configuration loaded successfully.");
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "CPSLimiter" + " started! Made by " + ChatColor.LIGHT_PURPLE + "lrxh#0001");

    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        long currentTime = System.currentTimeMillis();

        if (clickTimestamps.containsKey(player)) {
            long lastClickTime = clickTimestamps.get(player);
            double cps = calculateCPS(lastClickTime, currentTime);

            if (cps > cpsLimit) {
                kickPlayer(player);
                sendStaffMessage(player);
                clickTimestamps.remove(player); // Reset the click timestamp after kicking
                return;
            }
        }

        clickTimestamps.put(player, currentTime);
    }

    private double calculateCPS(long lastClickTime, long currentTime) {
        double timeElapsed = (currentTime - lastClickTime) / 1000.0; // Convert to seconds
        return 1.0 / timeElapsed;
    }

    private void kickPlayer(Player player) {
        new BukkitRunnable() {
            @Override
            public void run() {
            }
        }.runTask(this);
    }

    private void sendStaffMessage(Player player) {
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (onlinePlayer.hasPermission(Constants.getStaffPerm())) {
                onlinePlayer.sendMessage(Constants.getSecondColor() + "[" + Constants.getMainColor() + "CPSLimiter" + Constants.getSecondColor() + "]" + Constants.getSecondColor() + " Player " + Constants.getMainColor() + player.getName() + Constants.getSecondColor() + " exceeded " + Constants.getMainColor() + Constants.getCPSLimit() + " CPS");
            }
        }
    }
}
