package lrxh;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

public class Constants {

    private static FileConfiguration config;

    public static void loadConfig(Plugin plugin) {
        config = plugin.getConfig();
    }

    public static ChatColor getMainColor() {
        return ChatColor.valueOf(config.getString("MainColor"));
    }

    public static ChatColor getSecondColor() {
        return ChatColor.valueOf(config.getString("SecondColor"));
    }

    public static String getStaffPerm() {
        return config.getString("StaffPermission");
    }
    
    public static int getCPSLimit() {
        return config.getInt("CPSLimit");
    }

    
}
